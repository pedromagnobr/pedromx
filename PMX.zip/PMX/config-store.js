// Serialized, revision-checked backups. Never push a backup over live site data.
let pmxCopyQueue=Promise.resolve();
async function pmxReadConfigs(url){
 const data=await chrome.storage.local.get('pmxConfigCopies'),records={};
 for(const [key,record] of Object.entries(data.pmxConfigCopies||{}))
  if(pmxConfigAllowed(key,url)&&pmxConfigValid(key,record.value))records[key]=record;
 return {ok:true,records};
}
function pmxWriteConfig(message,url){
 const run=async()=>{
  const {key,value,baseRevision}=message;
  if(!pmxConfigAllowed(key,url)||!pmxConfigValid(key,value))return {ok:false,error:'Configuração não autorizada ou inválida.'};
  const data=await chrome.storage.local.get('pmxConfigCopies'),records=data.pmxConfigCopies||{},previous=records[key];
  if((previous?.revision||0)!==baseRevision)return {ok:false,conflict:true,revision:previous?.revision||0};
  if(previous&&previous.value===value)return {ok:true,revision:previous.revision,changed:false};
  const record={value,revision:(previous?.revision||0)+1,updatedAt:Date.now()};
  records[key]=record;
  try{await chrome.storage.local.set({pmxConfigCopies:records,pmxConfigCopyError:null})}
  catch(error){await chrome.storage.local.set({pmxConfigCopyError:'Não foi possível salvar a cópia das configurações na extensão.'}).catch(()=>{});throw error}
  return {ok:true,revision:record.revision,changed:true};
 };
 const result=pmxCopyQueue.then(run);pmxCopyQueue=result.catch(()=>{});return result;
}
async function pmxConfigStatus(){
 const data=await chrome.storage.local.get(['pmxConfigCopies','pmxConfigCopyError']);
 const records=Object.values(data.pmxConfigCopies||{}).filter(r=>r.value!==null);
 return {ok:true,count:records.length,lastSaved:Math.max(0,...records.map(r=>r.updatedAt)),error:data.pmxConfigCopyError||null};
}
