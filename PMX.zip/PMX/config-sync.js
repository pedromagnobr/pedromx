(()=>{
 const keys=Object.keys(PMX_CONFIG_RULES).filter(key=>pmxConfigAllowed(key,location.href));
 if(!keys.length)return;
 const initial={},states={};let busy=false,ready=false,timer,noticeTimer;
 function notify(message,error=false){
  if(!document.body){addEventListener('DOMContentLoaded',()=>notify(message,error),{once:true});return}
  let box=document.getElementById('pmx-config-copy-notice');
  if(!box){box=document.createElement('div');box.id='pmx-config-copy-notice';box.setAttribute('role','status');box.style.cssText='position:fixed;bottom:18px;left:50%;transform:translateX(-50%);z-index:2147483647;background:#111;color:#fff;border:1px solid #888;border-radius:10px;padding:12px 18px;max-width:85vw;font:14px system-ui;text-align:center;pointer-events:none';document.body.append(box)}
  box.textContent=message;box.hidden=false;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>box.hidden=true,error?12000:3500);
 }
 const call=message=>chrome.runtime.sendMessage(message);
 async function scan(){
  if(!ready||busy)return;busy=true;
  try{
   for(const key of keys){
    const state=states[key];
    for(let attempt=0;attempt<4;attempt++){
     const value=localStorage.getItem(key);
     if(value===state.saved)break;
     if(!pmxConfigValid(key,value)){notify('Configuração inválida: a cópia anterior foi preservada.',true);break}
     const result=await call({type:'PMX_CONFIG_WRITE',key,value,baseRevision:state.revision});
     if(result.conflict){state.revision=result.revision;continue}
     if(!result.ok)throw Error(result.error);
     state.revision=result.revision;state.saved=value;
     if(result.changed)notify('Configuração copiada para a extensão PMX');
     // Read the live value again: a newer edit may have arrived while saving.
    }
   }
  }catch{notify('Não foi possível copiar a configuração para a extensão PMX. Mantenha a página aberta e tente novamente.',true)}
  finally{busy=false}
 }
 async function start(){
  try{
   for(const key of keys)initial[key]=localStorage.getItem(key);
   const response=await call({type:'PMX_CONFIG_READ'});
   if(!response?.ok)throw Error('read');
   let restored=false;
   for(const key of keys){
    const record=response.records[key];
    states[key]={revision:record?.revision||0,saved:record?record.value:null};
    // Restoration is only for missing data at startup, never on online/offline events.
    if(initial[key]===null&&localStorage.getItem(key)===null&&record?.value!=null){
     localStorage.setItem(key,record.value);restored=true;
    }
   }
   if(restored){location.reload();return}
   ready=true;await scan();timer=setInterval(scan,750);
   for(const event of ['storage','online','offline','visibilitychange','pagehide'])addEventListener(event,scan);
   for(const event of ['click','change','input','submit'])document.addEventListener(event,()=>setTimeout(scan,0),true);
  }catch{notify('A cópia de segurança PMX está indisponível. Recarregue a página após verificar a extensão.',true)}
 }
 void start();
})();
