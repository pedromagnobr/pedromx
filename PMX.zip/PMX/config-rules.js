globalThis.PMX_CONFIG_RULES=Object.freeze({
 'pmx-index-config-v2':{paths:['/indice/'],json:true},
 'spscom-index-config-v1':{paths:['/SPSCOM/'],json:true},
 'sumario-vault':{paths:['/SPSCOM/','/spscom/Sumário/','/obsidian.md/SPSCOM/Sumário/'],json:false},
 'pmx-totp-appearance-v1':{paths:['/totp/'],json:true}
});
globalThis.pmxConfigPath=url=>{const u=new URL(url);if(u.origin!=='https://p.pedromx.com')return '';let p=decodeURIComponent(u.pathname).replace(/index\.html?$/i,'');if(!p.endsWith('/')&&!/\.html?$/i.test(p))p+='/';return p};
globalThis.pmxConfigAllowed=(key,url)=>{try{return !!PMX_CONFIG_RULES[key]?.paths.includes(pmxConfigPath(url))}catch{return false}};
globalThis.pmxConfigValid=(key,value)=>{const rule=PMX_CONFIG_RULES[key];if(!rule)return false;if(value===null)return true;if(typeof value!=='string'||value.length>5000000||!value.trim())return false;if(!rule.json)return value.length<=120;try{const v=JSON.parse(value);return v&&typeof v==='object'&&!Array.isArray(v)}catch{return false}};
