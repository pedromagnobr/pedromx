const AEGIS_URL='https://p.pedromx.com/aegis/',AEGIS_CURRENT_MENU='aegis-open-current';
function aegisCurrentUrl(tab){return tab?.pendingUrl||tab?.url||''}
function aegisIsApplication(value){try{const url=new URL(value);return url.origin==='https://p.pedromx.com'&&['/aegis/','/aegis','/aegis/index.html'].includes(url.pathname)}catch{return false}}
function aegisIsNewTab(value){return /^(?:edge|chrome):\/\/(?:newtab|new-tab-page)\/?(?:[?#].*)?$/i.test(value)||/^about:newtab(?:[?#].*)?$/i.test(value)||/^(?:edge|chrome)-search:\/\/local-ntp\/local-ntp\.html(?:[?#].*)?$/i.test(value)}
async function aegisOpen(tab,current=false){const id=Number.isInteger(tab?.id)&&tab.id>=0?tab.id:null,url=aegisCurrentUrl(tab);if(id!==null){if(aegisIsApplication(url)){await chrome.tabs.reload(id);return}if(current||aegisIsNewTab(url)){await chrome.tabs.update(id,{url:AEGIS_URL});return}}await chrome.tabs.create({url:AEGIS_URL})}
function aegisLaunch(tab,current=false){void aegisOpen(tab,current).catch(()=>{})}
function aegisInstallMenu(){chrome.contextMenus.remove(AEGIS_CURRENT_MENU,()=>{void chrome.runtime.lastError;chrome.contextMenus.create({id:AEGIS_CURRENT_MENU,title:'Abrir Aegis nesta guia',contexts:['action']},()=>{void chrome.runtime.lastError})})}
chrome.action.onClicked.addListener(tab=>aegisLaunch(tab));chrome.contextMenus.onClicked.addListener((info,tab)=>{if(info.menuItemId===AEGIS_CURRENT_MENU)aegisLaunch(tab,true)});chrome.runtime.onInstalled.addListener(aegisInstallMenu);chrome.runtime.onStartup.addListener(aegisInstallMenu);
