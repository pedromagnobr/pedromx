const AEGIS_URL='https://p.pedromx.com/aegis/';
function aegisCurrentUrl(tab){return tab?.pendingUrl||tab?.url||''}
function aegisIsApplication(value){try{const url=new URL(value);return url.origin==='https://p.pedromx.com'&&['/aegis/','/aegis','/aegis/index.html'].includes(url.pathname)}catch{return false}}
function aegisIsNewTab(value){return /^(?:edge|chrome):\/\/(?:newtab|new-tab-page)\/?(?:[?#].*)?$/i.test(value)||/^about:newtab(?:[?#].*)?$/i.test(value)||/^(?:edge|chrome)-search:\/\/local-ntp\/local-ntp\.html(?:[?#].*)?$/i.test(value)}
async function aegisOpen(tab){const id=Number.isInteger(tab?.id)&&tab.id>=0?tab.id:null,url=aegisCurrentUrl(tab);if(id!==null){if(aegisIsApplication(url)){await chrome.tabs.reload(id);return}if(aegisIsNewTab(url)){await chrome.tabs.update(id,{url:AEGIS_URL});return}}await chrome.tabs.create({url:AEGIS_URL})}
function aegisLaunch(tab){void aegisOpen(tab).catch(()=>{})}
chrome.action.onClicked.addListener(tab=>aegisLaunch(tab));
