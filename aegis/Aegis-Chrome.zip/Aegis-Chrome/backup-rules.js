globalThis.AEGIS_KEYS=['aegis-local-v1','aegis-time-offset-v1','aegis-lock-enabled-v1','aegis-config-password-v1','aegis-appearance-v1'];
globalThis.validAegisSnapshot=value=>{
 if(!value||typeof value!=='object'||Object.keys(value).length!==AEGIS_KEYS.length)return false;
 if(!AEGIS_KEYS.every(k=>Object.hasOwn(value,k)&&(value[k]===null||typeof value[k]==='string')))return false;
 if(JSON.stringify(value).length>5000000)return false;
 try{
  const raw=value[AEGIS_KEYS[0]],vault=JSON.parse(raw||'null'),flag=value[AEGIS_KEYS[2]];
  if(flag!==null&&flag!=='1')return false;
  if(vault!==null&&!Array.isArray(vault)){
   if(vault.format!=='aegis-lock-v1'||vault.version!==1)return false;
   for(const field of ['salt','iv','ciphertext'])if(typeof vault[field]!=='string'||!vault[field])return false;
  }
  if(flag==='1'&&vault?.format!=='aegis-lock-v1')return false;
  for(const key of [AEGIS_KEYS[3],AEGIS_KEYS[4]])if(value[key]!==null){const v=JSON.parse(value[key]);if(!v||typeof v!=='object'||Array.isArray(v))return false}
  if(value[AEGIS_KEYS[1]]!==null&&!Number.isFinite(Number(value[AEGIS_KEYS[1]])))return false;
  return true;
 }catch{return false}
};
