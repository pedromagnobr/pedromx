let backupQueue=Promise.resolve();
async function handleBackup(message,sender){
 if(sender.id!==chrome.runtime.id||sender.frameId!==0||!aegisIsApplication(sender.url||sender.tab?.url))return {ok:false};
 if(message.type==='AEGIS_BACKUP_READ'){const data=await chrome.storage.local.get('aegisBackup');return {ok:true,record:data.aegisBackup||null}}
 if(message.type!=='AEGIS_BACKUP_WRITE'||!validAegisSnapshot(message.value))return {ok:false,error:'Configuração inválida'};
 const run=async()=>{
  const data=await chrome.storage.local.get('aegisBackup'),old=data.aegisBackup;
  if((old?.revision||0)!==message.revision)return {ok:false,conflict:true,revision:old?.revision||0};
  if(old&&JSON.stringify(old.value)===JSON.stringify(message.value))return {ok:true,revision:old.revision};
  const record={value:message.value,revision:(old?.revision||0)+1,savedAt:Date.now()};
  await chrome.storage.local.set({aegisBackup:record});return {ok:true,revision:record.revision};
 };
 const pending=backupQueue.then(run);backupQueue=pending.catch(()=>{});return pending;
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
 if(!['AEGIS_BACKUP_READ','AEGIS_BACKUP_WRITE'].includes(message?.type))return;
 handleBackup(message,sender).then(respond,()=>respond({ok:false,error:'Falha ao salvar cópia local'}));return true;
});
