// A wake-up signal only: no secrets, PINs or configuration data cross this event.
(()=>{
 const keys=new Set(['aegis-local-v1','aegis-time-offset-v1','aegis-lock-enabled-v1','aegis-config-password-v1','aegis-appearance-v1']);
 for(const method of ['setItem','removeItem','clear']){
  const original=Storage.prototype[method];
  Storage.prototype[method]=function(...args){
   const result=Reflect.apply(original,this,args);
   if(this===localStorage&&(method==='clear'||keys.has(String(args[0]))))window.dispatchEvent(new Event('aegis-storage-updated'));
   return result;
  };
 }
})();
