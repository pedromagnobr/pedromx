(()=>{
 const marker='aegis-extension-deleted-v1';
 const read=()=>Object.fromEntries(AEGIS_KEYS.map(k=>[k,localStorage.getItem(k)]));
 const empty=v=>AEGIS_KEYS.every(k=>v[k]===null);
 let revision=0,saved='',ready=false,busy=false,pending=false,noticeTimer,starting=false,retries=0;
 function notice(text){
  if(!document.body){document.addEventListener('DOMContentLoaded',()=>notice(text),{once:true});return}
  let box=document.getElementById('aegis-extension-backup-status');
  if(!box){box=document.createElement('div');box.id='aegis-extension-backup-status';box.setAttribute('role','status');box.style.cssText='position:fixed;bottom:16px;left:50%;transform:translateX(-50%);z-index:2147483647;max-width:85vw;padding:12px 18px;border:1px solid #888;border-radius:10px;background:#111;color:#fff;font:14px system-ui;text-align:center';document.body.append(box)}
  box.textContent=text;box.hidden=false;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>box.hidden=true,5000);
 }
 async function sync(){
  if(!ready)return;if(busy){pending=true;return}busy=true;
  try{
   do{
    pending=false;
    const value=read(),serialized=JSON.stringify(value);
    if(serialized===saved||!validAegisSnapshot(value))break;
    const result=await chrome.runtime.sendMessage({type:'AEGIS_BACKUP_WRITE',value,revision});
    if(result?.conflict){revision=result.revision;pending=true;continue}
    if(!result?.ok)throw Error('save');
    revision=result.revision;saved=serialized;
    pending=JSON.stringify(read())!==saved;
    if(!pending)notice(navigator.onLine?'Dados salvos na extensão':'Usando dados salvos na extensão');
   }while(pending);
  }catch{notice('Não foi possível salvar a cópia na extensão Aegis. Mantenha a página aberta e tente novamente.')}
  finally{busy=false}
 }
 // Record intentional deletion synchronously, even when the app immediately reloads.
 addEventListener('aegis-storage-updated',()=>{
  if(localStorage.getItem(AEGIS_KEYS[0])===null)localStorage.setItem(marker,'1');
  else localStorage.removeItem(marker);
  void sync();
 });
 async function start(){
  if(ready||starting)return;starting=true;
  try{
   const initial=read(),result=await chrome.runtime.sendMessage({type:'AEGIS_BACKUP_READ'});
   if(!result?.ok)throw Error('read');
   const record=result.record;revision=record?.revision||0;saved=record?JSON.stringify(record.value):JSON.stringify(read());if(!navigator.onLine&&record&&validAegisSnapshot(record.value)&&!empty(record.value))notice('Usando dados salvos na extensão');
   if(record&&validAegisSnapshot(record.value)&&!empty(record.value)&&empty(initial)&&empty(read())&&localStorage.getItem(marker)!=='1'){
    try{
     for(const key of AEGIS_KEYS)if(record.value[key]!==null)localStorage.setItem(key,record.value[key]);
    }catch(error){
     // Roll back partial restoration if the site's storage quota is exhausted.
     for(const key of AEGIS_KEYS)localStorage.removeItem(key);
     throw error;
    }
    location.reload();return;
   }
   if(!record)saved='';
   ready=true;retries=0;await sync();setInterval(sync,750);
   for(const event of ['storage','online','offline','pagehide','visibilitychange'])addEventListener(event,sync);
  }catch{if(chrome.runtime?.id)setTimeout(start,Math.min(30000,250*Math.pow(2,Math.min(retries++,7))))}
  finally{starting=false}
 }
 void start();
})();
