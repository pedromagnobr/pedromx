const AEGIS_URL='https://p.pedromx.com/aegis/';
function aegisCurrentUrl(tab){return tab?.pendingUrl||tab?.url||''}
function aegisIsApplication(value){try{const url=new URL(value);return url.origin==='https://p.pedromx.com'&&['/aegis/','/aegis','/aegis/index.html'].includes(url.pathname)}catch{return false}}
function aegisIsNewTab(value){return /^(?:edge|chrome):\/\/(?:newtab|new-tab-page)\/?(?:[?#].*)?$/i.test(value)||/^about:newtab(?:[?#].*)?$/i.test(value)||/^(?:edge|chrome)-search:\/\/local-ntp\/local-ntp\.html(?:[?#].*)?$/i.test(value)}
async function aegisOpen(tab){const id=Number.isInteger(tab?.id)&&tab.id>=0?tab.id:null,url=aegisCurrentUrl(tab);if(id!==null){if(aegisIsApplication(url)){aegisQueueFocus(id);await chrome.tabs.reload(id);return}if(aegisIsNewTab(url)){aegisQueueFocus(id);await chrome.tabs.update(id,{url:AEGIS_URL});return}}const created=await chrome.tabs.create({url:AEGIS_URL,active:true});aegisQueueFocus(created.id);aegisFocus(created.id)}
function aegisLaunch(tab){void aegisOpen(tab).catch(()=>{})}
chrome.action.onClicked.addListener(tab=>aegisLaunch(tab));
const aegisFocusPending=new Set();function aegisQueueFocus(tabId){if(Number.isInteger(tabId))aegisFocusPending.add(tabId)}function aegisFocus(tabId){for(const delay of [0,180,500,1000])setTimeout(()=>{chrome.tabs.sendMessage(tabId,{type:'AEGIS_FOCUS_PIN'}).catch(()=>{})},delay)}chrome.tabs.onUpdated.addListener((tabId,changeInfo)=>{if(changeInfo.status==='complete'&&aegisFocusPending.has(tabId)){aegisFocusPending.delete(tabId);aegisFocus(tabId)}});chrome.tabs.onRemoved.addListener(tabId=>aegisFocusPending.delete(tabId));

importScripts('backup-rules.js','backup-store.js');
